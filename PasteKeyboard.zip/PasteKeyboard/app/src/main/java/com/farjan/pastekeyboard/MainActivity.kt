package com.farjan.pastekeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Simple setup screen: enable the keyboard, pick it, and test it. */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        layout.addView(TextView(this).apply {
            setText(R.string.setup_title)
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            setText(R.string.setup_body)
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        })
        layout.addView(Button(this).apply {
            setText(R.string.btn_enable)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        layout.addView(Button(this).apply {
            setText(R.string.btn_pick)
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        })
        layout.addView(EditText(this).apply {
            setHint(R.string.test_hint)
        })

        setContentView(ScrollView(this).apply { addView(layout) })
    }
}

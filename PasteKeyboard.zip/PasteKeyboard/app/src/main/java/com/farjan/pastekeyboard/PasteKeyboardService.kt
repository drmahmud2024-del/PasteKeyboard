package com.farjan.pastekeyboard

import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min

/**
 * A small QWERTY keyboard with a dedicated Paste button.
 * The green Paste bar appears above the keys whenever the clipboard has text.
 */
class PasteKeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, SYMBOLS1, SYMBOLS2 }

    private lateinit var clipboard: ClipboardManager
    private var keysContainer: LinearLayout? = null
    private var pasteButton: TextView? = null

    private var mode = Mode.LETTERS
    private var shifted = false
    private var capsLock = false
    private var lastShiftTap = 0L
    private var passwordField = false

    private val handler = Handler(Looper.getMainLooper())
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { refreshPasteButton() }

    private val bgColor = Color.parseColor("#1F2329")
    private val keyColor = Color.parseColor("#3A4048")
    private val specialColor = Color.parseColor("#2C3138")
    private val accentColor = Color.parseColor("#2E7D32")

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipboard.removePrimaryClipChangedListener(clipListener)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }

        pasteButton = TextView(this).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(16), 0, dp(16), 0)
            background = keyBg(accentColor)
            isClickable = true
            visibility = View.GONE
            setOnClickListener { pasteFromClipboard() }
        }
        root.addView(
            pasteButton,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply {
                setMargins(dp(3), 0, dp(3), dp(6))
            }
        )

        keysContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(
            keysContainer,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        renderKeys()
        refreshPasteButton()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
            Mode.SYMBOLS1
        } else {
            Mode.LETTERS
        }
        passwordField = isPasswordField(info)
        if (!capsLock) shifted = false
        renderKeys()
        updateAutoCaps()
        refreshPasteButton()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacksAndMessages(null)
        super.onFinishInputView(finishingInput)
    }

    // ---------------------------------------------------------------- clipboard

    /** Returns (text, isSensitive) or null if the clipboard has no text. */
    private fun currentClip(): Pair<CharSequence, Boolean>? {
        return try {
            val clip = clipboard.primaryClip ?: return null
            if (clip.itemCount == 0) return null
            val text = clip.getItemAt(0).coerceToText(this)
            if (text.isNullOrEmpty()) return null
            val sensitive = clip.description.extras
                ?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true
            Pair(text, sensitive)
        } catch (e: Exception) {
            null
        }
    }

    private fun refreshPasteButton() {
        val btn = pasteButton ?: return
        val clip = currentClip()
        if (clip == null) {
            btn.visibility = View.GONE
            return
        }
        val (text, sensitive) = clip
        val hidePreview = sensitive || passwordField
        val preview = if (hidePreview) "" else "   •   " + text.toString().replace('\n', ' ').trim()
        btn.text = "📋  Paste$preview"
        btn.visibility = View.VISIBLE
    }

    private fun pasteFromClipboard() {
        val (text, _) = currentClip() ?: return
        currentInputConnection?.commitText(text, 1)
        updateAutoCaps()
    }

    // ---------------------------------------------------------------- key layout

    private fun renderKeys() {
        val c = keysContainer ?: return
        c.removeAllViews()
        when (mode) {
            Mode.LETTERS -> {
                c.addView(charRow("1234567890"))
                c.addView(charRow("qwertyuiop"))
                c.addView(
                    row(spacer(0.5f)).also { r ->
                        "asdfghjkl".forEach { r.addView(charKey(it)) }
                        r.addView(spacer(0.5f))
                    }
                )
                c.addView(
                    row(shiftKey()).also { r ->
                        "zxcvbnm".forEach { r.addView(charKey(it)) }
                        r.addView(backspaceKey(1.5f))
                    }
                )
            }
            Mode.SYMBOLS1 -> {
                c.addView(charRow("1234567890"))
                c.addView(charRow("@#$%&-+()/"))
                c.addView(
                    row(key("=\\<", 1.5f, true) { mode = Mode.SYMBOLS2; renderKeys() }).also { r ->
                        "*\"':;!?".forEach { r.addView(charKey(it)) }
                        r.addView(backspaceKey(1.5f))
                    }
                )
            }
            Mode.SYMBOLS2 -> {
                c.addView(charRow("~`|•√π÷×¶∆"))
                c.addView(charRow("£৳€¥^°={}\\"))
                c.addView(
                    row(key("1/2", 1.5f, true) { mode = Mode.SYMBOLS1; renderKeys() }).also { r ->
                        "%©™[]<>".forEach { r.addView(charKey(it)) }
                        r.addView(backspaceKey(1.5f))
                    }
                )
            }
        }
        c.addView(bottomRow())
    }

    private fun bottomRow(): LinearLayout {
        val modeLabel = if (mode == Mode.LETTERS) "?123" else "ABC"
        return row(
            key(modeLabel, 1.5f, true) {
                mode = if (mode == Mode.LETTERS) Mode.SYMBOLS1 else Mode.LETTERS
                renderKeys()
            },
            key("🌐", 1f, true) { switchKeyboard() }.apply {
                setOnLongClickListener { showPicker(); true }
            },
            key(",", 1f) { typeText(",") },
            key("English", 4f) { typeText(" ") },
            key(".", 1f) { typeText(".") },
            key("⏎", 1.5f, true) { handleEnter() }
        )
    }

    private fun charRow(chars: String): LinearLayout =
        row().also { r -> chars.forEach { r.addView(charKey(it)) } }

    private fun charKey(ch: Char): TextView {
        val label = if (mode == Mode.LETTERS && shifted) ch.uppercaseChar().toString() else ch.toString()
        return key(label, 1f) { typeText(ch.toString()) }
    }

    private fun shiftKey(): TextView {
        val label = if (capsLock) "⇪" else if (shifted) "⬆" else "⇧"
        return key(label, 1.5f, true) {
            val now = SystemClock.uptimeMillis()
            if (now - lastShiftTap < 350) {
                capsLock = true
                shifted = true
            } else if (capsLock) {
                capsLock = false
                shifted = false
            } else {
                shifted = !shifted
            }
            lastShiftTap = now
            renderKeys()
        }
    }

    private fun backspaceKey(weight: Float): TextView {
        val tv = key("⌫", weight, true) {}
        val repeat = object : Runnable {
            override fun run() {
                deleteOne()
                handler.postDelayed(this, 50)
            }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    deleteOne()
                    handler.postDelayed(repeat, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(repeat)
                }
            }
            true
        }
        return tv
    }

    // ---------------------------------------------------------------- input actions

    private fun typeText(s: String) {
        val out = if (mode == Mode.LETTERS && shifted) s.uppercase() else s
        currentInputConnection?.commitText(out, 1)
        if (mode == Mode.LETTERS && shifted && !capsLock) {
            shifted = false
            renderKeys()
        }
        updateAutoCaps()
    }

    private fun deleteOne() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        updateAutoCaps()
    }

    private fun handleEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val multiLine = info != null &&
            (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        val noEnterAction = info != null &&
            (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        if (!multiLine && !noEnterAction &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun updateAutoCaps() {
        if (capsLock || mode != Mode.LETTERS) return
        val info = currentInputEditorInfo ?: return
        if (info.inputType == InputType.TYPE_NULL) return
        val want = (currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0) != 0
        if (want != shifted) {
            shifted = want
            renderKeys()
        }
    }

    private fun switchKeyboard() {
        val ok = try {
            switchToNextInputMethod(false)
        } catch (e: Throwable) {
            false
        }
        if (!ok) showPicker()
    }

    private fun showPicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun isPasswordField(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (
            v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            )) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    // ---------------------------------------------------------------- view helpers

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    private fun spacer(weight: Float): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, dp(50), weight)
    }

    private fun key(
        label: String,
        weight: Float,
        special: Boolean = false,
        onTap: () -> Unit
    ): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label.length > 1) 14f else 20f)
        background = keyBg(if (special) specialColor else keyColor)
        layoutParams = LinearLayout.LayoutParams(0, dp(50), weight).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
        }
        isClickable = true
        setOnClickListener { onTap() }
    }

    private fun keyBg(color: Int): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), rounded(lighten(color)))
        addState(intArrayOf(), rounded(color))
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(8).toFloat()
    }

    private fun lighten(c: Int): Int = Color.rgb(
        min(255, Color.red(c) + 40),
        min(255, Color.green(c) + 40),
        min(255, Color.blue(c) + 40)
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

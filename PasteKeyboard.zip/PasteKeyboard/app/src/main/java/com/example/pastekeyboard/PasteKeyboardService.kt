package com.example.pastekeyboard

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * একটা সাধারণ QWERTY কিবোর্ড, যার উপরে একটা ডেডিকেটেড Paste বাটন আছে।
 *
 * কিছু কপি করা থাকলে কিবোর্ড খুললেই উপরে Paste বাটন (আর কপি করা লেখার প্রিভিউ) দেখা যায়।
 * বাটন চাপলে লেখাটা সরাসরি বর্তমান টেক্সট বক্সে বসে যায়।
 *
 * Android 10+ এ ক্লিপবোর্ড পড়ার অনুমতি শুধু ফোকাসে থাকা অ্যাপ আর ডিফল্ট কিবোর্ডের (IME) থাকে।
 * এই অ্যাপ কিবোর্ড হিসেবে সিলেক্ট করা থাকলে তাই আলাদা কোনো permission লাগে না।
 */
class PasteKeyboardService : InputMethodService() {

    private enum class KeyStyle { NORMAL, SPECIAL, ACCENT }

    private companion object {
        const val SHIFT_OFF = 0
        const val SHIFT_ON = 1
        const val SHIFT_LOCKED = 2

        val BG = 0xFF1F2023.toInt()
        val KEY_NORMAL = 0xFF3C3F46.toInt()
        val KEY_NORMAL_PRESSED = 0xFF6A6E78.toInt()
        val KEY_SPECIAL = 0xFF2C2E33.toInt()
        val KEY_SPECIAL_PRESSED = 0xFF55585F.toInt()
        val KEY_ACCENT = 0xFF3D7BF0.toInt()
        val KEY_ACCENT_PRESSED = 0xFF6C9AF5.toInt()
        val PREVIEW_TEXT = 0xFFB8BCC4.toInt()
        val SPACES = Regex("\\s+")
    }

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var clipboard: ClipboardManager
    private lateinit var pasteBar: LinearLayout
    private lateinit var previewText: TextView
    private lateinit var lettersLayer: LinearLayout
    private lateinit var symbolsLayer: LinearLayout

    private var shiftKey: TextView? = null
    private val letterKeys = ArrayList<Pair<TextView, Char>>()

    private var shiftState = SHIFT_OFF
    private var shownShift = -1
    private var lastShiftTap = 0L

    private var clipText: String? = null
    private var clipSensitive = false

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        refreshClipboard()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipboard.removePrimaryClipChangedListener(clipListener)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        letterKeys.clear()
        shiftKey = null
        shownShift = -1

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(4), 0, dp(4), dp(8))
        }

        root.addView(buildPasteBar())

        lettersLayer = buildLettersLayer()
        symbolsLayer = buildSymbolsLayer()
        symbolsLayer.visibility = View.GONE
        root.addView(lettersLayer)
        root.addView(symbolsLayer)

        refreshShiftUi()
        refreshClipboard()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)

        // নম্বর/ফোন ফিল্ডে সরাসরি সংখ্যার লেআউট দেখাই
        if (::lettersLayer.isInitialized) {
            showSymbols(isNumericField(info))
        }

        if (shiftState != SHIFT_LOCKED) shiftState = SHIFT_OFF
        updateAutoShift()
        refreshShiftUi()

        // কিবোর্ড খোলার সময় ক্লিপবোর্ড আবার দেখে নিই
        refreshClipboard()
    }

    // ---------------------------------------------------------------- clipboard

    private fun refreshClipboard() {
        var text: String? = null
        var sensitive = false
        try {
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0 && clip.description.hasMimeType("text/*")) {
                text = clip.getItemAt(0).coerceToText(this)?.toString()
                    ?.takeIf { it.isNotEmpty() }
                if (Build.VERSION.SDK_INT >= 33) {
                    sensitive = clip.description.extras
                        ?.getBoolean(ClipDescription.EXTRA_IS_SENSITIVE, false) == true
                }
            }
        } catch (e: Exception) {
            // ক্লিপবোর্ড এই মুহূর্তে পড়া যাচ্ছে না; বাটন লুকিয়ে রাখি
        }
        clipText = text
        clipSensitive = sensitive
        updatePasteBar()
    }

    private fun updatePasteBar() {
        if (!::pasteBar.isInitialized) return
        val text = clipText
        if (text == null) {
            pasteBar.visibility = View.GONE
            return
        }
        pasteBar.visibility = View.VISIBLE
        // পাসওয়ার্ড ফিল্ড বা সংবেদনশীল ক্লিপে লেখা দেখাই না
        previewText.text = if (clipSensitive || isPasswordField()) {
            "••••••"
        } else {
            text.take(200).replace(SPACES, " ").trim()
        }
    }

    private fun performPaste() {
        refreshClipboard()
        val text = clipText ?: return
        currentInputConnection?.commitText(text, 1)
        afterInput()
    }

    private fun isPasswordField(): Boolean {
        val type = currentInputEditorInfo?.inputType ?: return false
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        return when (cls) {
            InputType.TYPE_CLASS_TEXT ->
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }

    private fun isNumericField(info: EditorInfo?): Boolean {
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        return cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
    }

    // ---------------------------------------------------------------- building the UI

    private fun buildPasteBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(2))
            visibility = View.GONE
        }

        val button = TextView(this).apply {
            text = getString(R.string.paste_button)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(18), 0, dp(18), 0)
            background = keyBackground(KeyStyle.ACCENT)
            isClickable = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40))
        }
        attachTouch(button, repeat = false, onRelease = true) { performPaste() }

        previewText = TextView(this).apply {
            setTextColor(PREVIEW_TEXT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(12), 0, dp(4), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        bar.addView(button)
        bar.addView(previewText)
        pasteBar = bar
        return bar
    }

    private fun buildLettersLayer(): LinearLayout {
        val layer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        layer.addView(row().apply {
            "qwertyuiop".forEach { addView(letterKey(it)) }
        })

        layer.addView(row().apply {
            addView(spacer(0.5f))
            "asdfghjkl".forEach { addView(letterKey(it)) }
            addView(spacer(0.5f))
        })

        layer.addView(row().apply {
            val shift = makeKey("⇧", 1.5f, KeyStyle.SPECIAL) { onShiftTap() }
            shiftKey = shift
            addView(shift)
            "zxcvbnm".forEach { addView(letterKey(it)) }
            addView(deleteKey(1.5f))
        })

        layer.addView(bottomRow(symbols = false))
        return layer
    }

    private fun buildSymbolsLayer(): LinearLayout {
        val layer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        layer.addView(row().apply {
            "1234567890".forEach { addView(symbolKey(it)) }
        })

        layer.addView(row().apply {
            addView(spacer(0.5f))
            "@#\$%&-+()".forEach { addView(symbolKey(it)) }
            addView(spacer(0.5f))
        })

        layer.addView(row().apply {
            "/*\"':;!?".forEach { addView(symbolKey(it)) }
            addView(deleteKey(2f))
        })

        layer.addView(bottomRow(symbols = true))
        return layer
    }

    private fun bottomRow(symbols: Boolean): LinearLayout = row().apply {
        if (symbols) {
            addView(makeKey("ABC", 1.5f, KeyStyle.SPECIAL, 16f, onRelease = true) { showSymbols(false) })
        } else {
            addView(makeKey("?123", 1.5f, KeyStyle.SPECIAL, 16f, onRelease = true) { showSymbols(true) })
        }
        addView(makeKey("🌐", 1f, KeyStyle.SPECIAL, 18f, onRelease = true) { showKeyboardPicker() })
        addView(makeKey(",", 1f, KeyStyle.NORMAL) { typeText(",") })
        addView(makeKey("", 4f, KeyStyle.NORMAL) { typeText(" ") })
        addView(makeKey(".", 1f, KeyStyle.NORMAL) { typeText(".") })
        addView(makeKey("⏎", 1.5f, KeyStyle.ACCENT) { handleEnter() })
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
    }

    private fun spacer(weight: Float): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
    }

    private fun letterKey(c: Char): TextView {
        val key = makeKey(c.toString(), 1f, KeyStyle.NORMAL) { typeText(letterText(c)) }
        letterKeys.add(key to c)
        return key
    }

    private fun symbolKey(c: Char): TextView =
        makeKey(c.toString(), 1f, KeyStyle.NORMAL) { typeText(c.toString()) }

    private fun deleteKey(weight: Float): TextView =
        makeKey("⌫", weight, KeyStyle.SPECIAL, repeat = true) { deleteBackward() }

    private fun makeKey(
        label: String,
        weight: Float,
        style: KeyStyle,
        textSp: Float = 20f,
        repeat: Boolean = false,
        onRelease: Boolean = false,
        action: () -> Unit
    ): TextView {
        val key = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
            isClickable = true
            background = keyBackground(style)
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, weight
            ).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
        }
        attachTouch(key, repeat, onRelease, action)
        return key
    }

    private fun keyBackground(style: KeyStyle): StateListDrawable {
        val (normal, pressed) = when (style) {
            KeyStyle.NORMAL -> KEY_NORMAL to KEY_NORMAL_PRESSED
            KeyStyle.SPECIAL -> KEY_SPECIAL to KEY_SPECIAL_PRESSED
            KeyStyle.ACCENT -> KEY_ACCENT to KEY_ACCENT_PRESSED
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), rounded(pressed))
            addState(intArrayOf(), rounded(normal))
        }
    }

    private fun rounded(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(8).toFloat()
        setColor(color)
    }

    /**
     * কী চাপার সাথে সাথে কাজ করার জন্য touch listener ব্যবহার করা হয়েছে (click নয়),
     * তাই দ্রুত টাইপ করলেও কোনো অক্ষর বাদ পড়ে না। Delete চেপে ধরলে বারবার মুছবে।
     * [onRelease] true হলে আঙুল তোলার সময় কাজ হয় (যেমন Paste, লেআউট বদল)।
     */
    @Suppress("ClickableViewAccessibility")
    private fun attachTouch(view: View, repeat: Boolean, onRelease: Boolean, action: () -> Unit) {
        var repeater: Runnable? = null

        fun stopRepeat() {
            repeater?.let { handler.removeCallbacks(it) }
            repeater = null
        }

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (!onRelease) action()
                    if (repeat) {
                        val r = object : Runnable {
                            override fun run() {
                                action()
                                handler.postDelayed(this, 45)
                            }
                        }
                        repeater = r
                        handler.postDelayed(r, 400)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    stopRepeat()
                    val inside = event.x >= 0 && event.x <= v.width &&
                        event.y >= 0 && event.y <= v.height
                    if (onRelease && inside) action()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    stopRepeat()
                    true
                }
                else -> true
            }
        }
    }

    // ---------------------------------------------------------------- key actions

    private fun typeText(s: String) {
        currentInputConnection?.commitText(s, 1)
        afterInput()
    }

    private fun deleteBackward() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        afterInput()
    }

    private fun handleEnter() {
        val ic = currentInputConnection ?: return
        val options = currentInputEditorInfo?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0

        if (!noEnterAction &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        afterInput()
    }

    private fun showKeyboardPicker() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun showSymbols(show: Boolean) {
        lettersLayer.visibility = if (show) View.GONE else View.VISIBLE
        symbolsLayer.visibility = if (show) View.VISIBLE else View.GONE
    }

    // ---------------------------------------------------------------- shift handling

    private fun onShiftTap() {
        val now = SystemClock.uptimeMillis()
        shiftState = when {
            shiftState == SHIFT_LOCKED -> SHIFT_OFF
            shiftState == SHIFT_ON && now - lastShiftTap < 400 -> SHIFT_LOCKED
            shiftState == SHIFT_ON -> SHIFT_OFF
            else -> SHIFT_ON
        }
        lastShiftTap = now
        refreshShiftUi()
    }

    /** বাক্যের শুরুতে নিজে থেকে বড় হাতের অক্ষর (যদি ফিল্ডটা সেটা চায়)। */
    private fun updateAutoShift() {
        if (shiftState == SHIFT_LOCKED) return
        val ic = currentInputConnection
        val ei = currentInputEditorInfo
        val wantsCaps = ic != null && ei != null &&
            ei.inputType != InputType.TYPE_NULL &&
            ic.getCursorCapsMode(ei.inputType) != 0
        shiftState = if (wantsCaps) SHIFT_ON else SHIFT_OFF
    }

    private fun afterInput() {
        updateAutoShift()
        refreshShiftUi()
    }

    private fun letterText(c: Char): String =
        if (shiftState != SHIFT_OFF) c.uppercaseChar().toString() else c.toString()

    private fun refreshShiftUi() {
        if (shownShift == shiftState) return
        shownShift = shiftState

        for ((key, c) in letterKeys) key.text = letterText(c)

        shiftKey?.let { key ->
            key.text = if (shiftState == SHIFT_LOCKED) "⇪" else "⇧"
            key.background =
                keyBackground(if (shiftState == SHIFT_OFF) KeyStyle.SPECIAL else KeyStyle.ACCENT)
        }
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()
}
